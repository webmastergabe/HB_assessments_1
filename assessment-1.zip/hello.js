/* 
You don't need to make any changes to this file - it's just here so that
you can run it to verify you've properly downloaded all the materials
*/

console.log("You're ready to begin!");